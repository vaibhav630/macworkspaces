package com.testexpress.learn.apiframework;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.testexpress.learn.apiobjects.Data;
import com.testexpress.learn.apiobjects.ObjectPojo;

public class BaseAPI {
	
	//https://easy-json-schema.github.io/
	//https://restful-api.dev/
	
	public String serializePayload() {
		
		String jsonString="null payload";
				
				// Create Data object
		        Data productData = new Data();
		        productData.setCpuModel(null);
		        productData.setHardDiskSize(null);
		        productData.setPrice(0);
		        productData.setYear(0);

		        // Create Product object and set Data
		        ObjectPojo product = new ObjectPojo();
		        product.setName("Google Pixel 6 Pro");
		        product.setData(productData);
		        
		        // ObjectMapper instance
		        ObjectMapper objectMapper = new ObjectMapper();

		        try {
		            // Convert Product object to JSON string
		            jsonString = objectMapper.writeValueAsString(product);
		            System.out.println(jsonString);
		        } catch (Exception e) {
		            e.printStackTrace();
		        }
				return jsonString;
	}

}
