package com.testexpress.learn.testlayer;

import org.testng.annotations.Test;

import java.nio.file.Files;
import java.nio.file.Paths;

import com.testexpress.learn.apiframework.BaseAPI;
import io.restassured.* ;
import io.restassured.response.Response;
import io.restassured.http.ContentType;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.path.json.JsonPath;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;

import java.io.File;
import java.io.IOException;


public class TestObjectCreationAPI extends BaseAPI{


	@Test
	public void testCreateObjectAPI() throws IOException{
		RestAssured.baseURI = "https://api.restful-api.dev/";

		Response response = RestAssured.given().when().get("/objects");
		
		System.out.println(response.getStatusCode());
		
		
		System.out.println(response.getBody().asPrettyString());
		
		System.out.println(response.body().jsonPath().get("[0].name").toString());

		
	}
	
	@Test
	public void testresponsenode() {
		
	RestAssured.baseURI = "https://api.restful-api.dev/";

	String response = RestAssured.get("/objects").asString();
	
	JsonPath jsonPath = new JsonPath(response.toString());

    // Fetch specific node
    String specificNode = jsonPath.get("[0].name").toString();
    System.out.println(specificNode);
	}
	
	@Test
	public void validateJsonSchema() {
		
		File file = new File("/Users/veenavyas/Documents/vaibhav/eclipseworkspaces/vs_test1/apiframework/src/main/java/com/testexpress/learn/jsonschemas/ObjectSchema.json");
		
		RestAssured.baseURI = "https://api.restful-api.dev/";

		Response response = RestAssured.get("/objects");
		
		response.then().assertThat()
            .body(JsonSchemaValidator.matchesJsonSchema(file));
          
    }
	
	@Test
	public void testPostAPI(){
		
		RestAssured.baseURI = "https://api.restful-api.dev/";
		
		 // Example JSON body
        String jsonBody = serializePayload();
        
		
		// Send POST request and print the response
        String response = RestAssured.given()
                .header("Content-Type", "application/json")
                .body(jsonBody)
                .when()
                .post("/objects")
                .then()
                .statusCode(200) // Expecting status code 201 for successful creation
                .extract().asString();

        System.out.println("Response: " + response);
		
		
		
		
	}
}


