package com.testexpress.learn.apiobjects;

public class ObjectPojo {
	
	private String name;
	private Data data;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Object getData() {
		return data;
	}
	public void setData(Data data) {
		this.data = data;
	}
	

}
