package com.testexpress.learn.interviewquestions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GroupAnagrams {

	public static void main(String[] args) {
		// Problem : Group all Anagrams together from Array of String
		String[] strs = {"vaibhav","deepak","baihvav"};
		List<List<String>> groupedlist = groupAnagrams(strs);
		for(List l: groupedlist) {
			System.out.println(l);
		}	
	}
	
	public static List<List<String>> groupAnagrams(String[] strs) {
		if (strs == null || strs.length == 0) {
		return new ArrayList<>();
		}
	
	// Initialize the hash map to store the grouped anagrams
	Map<String, List<String>> anagramMap = new HashMap<>();
	// Iterate over each string in the array
	for (String str : strs) {
		// Convert the string to a char array, sort it, and convert it back to a string
		char[] charArray = str.toCharArray();
		Arrays.sort(charArray);
		String sortedStr = new String(charArray);
		// Add the original string to the list of anagrams for the sorted key
		anagramMap.computeIfAbsent(sortedStr, k -> new ArrayList<>()).add(str);
	}
	// Collect all the grouped anagrams from the hash map
	return new ArrayList<>(anagramMap.values());
}

	
}
