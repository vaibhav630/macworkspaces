package com.testexpress.learn.Iteratorsbasics;

import java.util.Enumeration;
import java.util.Vector;

public class EnumeratorPractice {

	public static void main(String[] args) {
		// create a new vector
		Vector v = new Vector();
		
		//initialize vector with numbers
		for(int i=0; i< 10; i++) {
			v.addElement(i);
		}
		
		//create an enumerator 
		Enumeration enu = v.elements();
		
		//show vector content
		while(enu.hasMoreElements()) {
			Integer i = (Integer)enu.nextElement();
			System.out.println(i);
		}
	}

}
