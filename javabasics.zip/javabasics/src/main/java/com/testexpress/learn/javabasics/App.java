package com.testexpress.learn.javabasics;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	List<String> mylist = new ArrayList<String>();
    	
    	mylist.add("vaibhav");
    	mylist.add("deepak");
    	mylist.add("yogesh");
    	
    	HashMap<Integer,List<String>> mymap = new HashMap<Integer,List<String>>();
    	int len;
    	for(String str:mylist) {
    		len= str.length();
    		mymap.computeIfAbsent(len, k -> new ArrayList<>()).add(str);
    	}
    	
    	for(Entry entry: mymap.entrySet()) {
    	System.out.println(entry.getKey());
    	System.out.println(entry.getValue());
    	}
    	
    	String name = "Vaibhav";
    	
    	HashMap<Character,Integer> charmap = new HashMap<Character,Integer>();
    	
//    	int count=1;
//    	for(char ch:name.toCharArray()) {
//    		if(charmap.containsKey(ch)) {
//    			charmap.put(ch, charmap.get(ch)+1) ;
//    		}
//    		else {
//    			charmap.put(ch, 1);
//    		}
//    		
//    		
//    		//mymap.computeIfAbsent(ch, k -> count)
//    	}	
    	
    	for(char ch:name.toCharArray()) {
        	charmap.put(ch, charmap.getOrDefault(ch, 0) + 1);
        	}
    	
    	charmap.entrySet().stream().
    	forEach(entry->System.out.println("Char: "+ entry.getKey() + " has occured " +entry.getValue() +" times"));
    	
    	
    }
}
