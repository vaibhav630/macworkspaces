package com.testexpress.learn.interviewquestions;

import java.util.Arrays;

public class MaxlengthConsecutiveNumbers {

	public static void main(String[] args) {
		// Write a program to find the length of the longest consecutive elements
		// sequence in an unsorted array of integers

		int[] arrint1 = { 100, 101, 1, 200, 3, 2, 4, 300, 500, 600, 5, 6, 400, 102, 103, 104, 105, 106, 107 };
		Arrays.sort(arrint1);
		int maxLength = 0;
		int left = 0;
		for (int right = 1; right < arrint1.length; right++) {
			if (arrint1[right] != arrint1[right - 1] + 1) {
				left = right;
			}
			maxLength = Math.max(maxLength, right - left + 1);
		}
		System.out.println(maxLength);

	}

}
