package com.testexpress.learn.interviewquestions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FindAllSubstrings {

	public static void main(String[] args) {	  
	
		String str = "VaibhaV";
		
		findAllSubString(str);


	    }

	private static void findAllSubString(String s) {
		// code to find all substrings of a given string
		List<String> list = new ArrayList<String>();
		String s1 ="";
		
		for(int i =0;i<s.length();i++) {
			char c = s.charAt(i);
			list.add(String.valueOf(c));
			s1 = String.valueOf(c);
		
			for(int j= i+1;j<s.length();j++) {
				s1 = s1 + String.valueOf(s.charAt(j)) ;
				list.add(String.valueOf(s1));
			}
			s1 = "";
		}

		for(String str:list) {
			System.out.println(str);
		}

		
	}
	

}
