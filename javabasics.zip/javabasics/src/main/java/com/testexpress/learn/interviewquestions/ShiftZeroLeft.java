package com.testexpress.learn.interviewquestions;

import java.util.Arrays;

public class ShiftZeroLeft {

	public static void main(String[] args) {
		// Program to shift all zeros to left and nonzeros to right in java
		int[] arr = { 0, 1, 0, 3, 12, 0, 5 };
		shiftZerosLeft(arr);
		System.out.println(Arrays.toString(arr));
	}

	public static void shiftZerosLeft(int[] arr) {
		int n = arr.length;
		// Initialize a pointer for the last non-zero element
		int j = n - 1;

		// Iterate through the array from the end to the beginning
		for (int i = n - 1; i >= 0; i--) {
			if (arr[i] != 0) {
				arr[j] = arr[i];
				j--;
			}
		}

		// Fill the remaining positions with zeros
		for (int i = 0; i <= j; i++) {
			arr[i] = 0;
		}
	}

}
