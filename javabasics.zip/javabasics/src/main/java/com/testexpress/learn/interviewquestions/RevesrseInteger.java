package com.testexpress.learn.interviewquestions;

public class RevesrseInteger {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Integer num = 12345;
		Integer rev = 0;
		while(num!=0)
		{
		rev = rev*10 + num%10; // % is modulus and returns a reminder
		num = num/10;
		}
		
		System.out.println(rev);
				
	}

}
