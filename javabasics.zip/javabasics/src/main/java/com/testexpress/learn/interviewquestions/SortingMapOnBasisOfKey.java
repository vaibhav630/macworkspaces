package com.testexpress.learn.interviewquestions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class SortingMapOnBasisOfKey {

	public static void main(String[] args) {
		// Sorting Map<Integer,String> in the basis of keys

		Map<Integer, String> map1 = new HashMap<Integer, String>();
		map1.put(3, "Deepak");
		map1.put(1, "Deepak");
		map1.put(2, "Deepak");
		List<Map.Entry<Integer, String>> list = new ArrayList<>(map1.entrySet());
		list.sort(Map.Entry.comparingByValue());
		Map<Integer, String> map2 = new LinkedHashMap<Integer, String>();
		for (Map.Entry<Integer, String> entry : list) {
			map2.put(entry.getKey(), entry.getValue());
		}
		for (Map.Entry<Integer, String> entry : map2.entrySet()) {
			System.out.println(entry.getKey());
		}
		System.out.println("");

	}
}