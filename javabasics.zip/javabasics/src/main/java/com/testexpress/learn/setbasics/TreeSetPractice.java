package com.testexpress.learn.setbasics;

import java.util.ArrayList;
import java.util.TreeSet;

public class TreeSetPractice {

	public static void main(String[] args) {

        // Create a TreeSet
        TreeSet<String> set = new TreeSet<>();

        // Add elements
        set.add("Apple");
        set.add("Banana");
        set.add("Cherry");
        set.add("Date");
        set.add("Elderberry");

        // Display the TreeSet
        System.out.println("TreeSet: " + set);

        // Get the first and last elements
        System.out.println("First element: " + set.first());
        System.out.println("Last element: " + set.last());

        // Get a subset of elements
        System.out.println("Head set (elements < 'Date'): " + set.headSet("Date"));
        System.out.println("Tail set (elements >= 'Date'): " + set.tailSet("Date"));
        System.out.println("Sub set (elements from 'Banana' to 'Date'): " + set.subSet("Banana", "Date"));

        // Get the comparator (null for natural ordering)
        System.out.println("Comparator: " + set.comparator());

        // Get a descending view of the TreeSet
        System.out.println("Descending set: " + set.descendingSet());

        // Retrieve and remove the first and last elements
        System.out.println("Poll first: " + set.pollFirst());
        System.out.println("TreeSet after pollFirst: " + set);
        System.out.println("Poll last: " + set.pollLast());
        System.out.println("TreeSet after pollLast: " + set);
        
        // Convert the TreeSet to an ArrayList
        ArrayList<String> arrayList = new ArrayList<>(set);

        // Display the ArrayList
        System.out.println("ArrayList from TreeSet:");
        for (String element : arrayList) {
            System.out.println(element);
        }

	}

}
