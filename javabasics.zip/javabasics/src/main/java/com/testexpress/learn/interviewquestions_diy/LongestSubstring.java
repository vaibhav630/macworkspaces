package com.testexpress.learn.interviewquestions_diy;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;

public class LongestSubstring {

	public static void main(String[] args) {

		// find longest substring without non repeating chars
		String str = "vaibhavV";
		longestSubstring(str);
		nonRepeatingchar(str);
	}

	private static void nonRepeatingchar(String str) {
		LinkedHashSet<Character> set = new LinkedHashSet<>();
		for (char ch : str.toCharArray()) {
			set.add(ch);
		}
		ArrayList<Character> uniqueChars = new ArrayList<>(set);
		System.out.println(uniqueChars);
		System.out.println("1st non repeating charater is: "+ uniqueChars.get(0));

	}

	public static void longestSubstring(String str) {

		HashSet<Character> set = new HashSet<>();

		for (char ch : str.toCharArray()) {
			set.add(ch);
		}

		System.out.println("max size: " + set.size());
		System.out.println("longest substring: " + set);

	}

}
