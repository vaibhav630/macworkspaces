package com.testexpress.learn.enumbasics;

import com.testexpress.learn.enumbasics.EnumWithMethodsAndConstrutors.Laptops;

public class EnumDefaultAndNew {

	enum Laptops{Macbook(20000), Thinkpad(16000), Latitude, Surface(12000);
		
		private int price;
		
	Laptops(int i) {
		this. price=i;
	}

	Laptops() {
		System.out.println(Laptops.valueOf(Latitude));
	}                           

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}}

	public static void main(String[] args) {
		//EnumWithMethodsAndConstrutors
//		Laptops lap = Laptops.Macbook;
//		System.out.println();
		
		for(Laptops lap:Laptops.values()){
		System.out.println(lap + " comes in price: "+ lap.getPrice());	
		}
		
	}

}
