package com.testexpress.learn.interviewquestions;

public class SortListOnBasisOfObjectProperty {

	public static void main(String[] args) {
//		Sort the List<object> in the basis of any fields in the object
//
//		Comparator Interface in Java with Examples - GeeksforGeeks
	}

}
