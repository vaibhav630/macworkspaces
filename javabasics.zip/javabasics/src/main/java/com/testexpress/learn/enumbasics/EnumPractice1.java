package com.testexpress.learn.enumbasics;

public class EnumPractice1 {
	
	enum Day{
		mon, tue, wed, thurs, fri, sat, sun
	}
	
	/* We need the enum constructor to be private 
	 * because enums define a finite set of values (SMALL, MEDIUM, LARGE). 
	 * If the constructor was public, people could potentially create more value. 
	 * (for example, invalid/undeclared values such as ANYSIZE, YOURSIZE, etc.).
	 * */
	
	/* Enum in Java contains fixed constant values. The constants are implicitly static and final, which cannot be modified. 
	 * So, there is no reason in having a public or protected constructor as you cannot create an enum instance. 
	 * Also, note that the internally enum is converted to class. 
	 * As we can’t create enum objects explicitly, hence we can’t call the enum constructor directly.
	 */
	
	/*enum is type-safe. It has its own namespace. */
	
	public static void main(String[] args) {
		
		int i=5;
		
		//Accessing enum constants
		Day day = Day.mon;
		
		//Getting all values from a enum
		Day[] dayArr = Day.values();
		
		//Iterate over enum 
		for(Day d:dayArr) {
			System.out.println(d + "day at "+ d.ordinal());   //getting position of enum value
		}
		
	}

}
