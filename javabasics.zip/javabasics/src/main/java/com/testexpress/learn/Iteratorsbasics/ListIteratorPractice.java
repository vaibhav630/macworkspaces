package com.testexpress.learn.Iteratorsbasics;

import java.util.ArrayList;
import java.util.ListIterator;

public class ListIteratorPractice {
    public static void main(String[] args) {
        // Create and populate an ArrayList
        ArrayList<String> list = new ArrayList<>();
        list.add("Apple");
        list.add("Banana");
        list.add("Cherry");
        list.add("Date");

        // Obtain a ListIterator for the ArrayList
        ListIterator<String> listIterator = list.listIterator();

        System.out.println("Forward iteration:");
        // Forward iteration using ListIterator
        while (listIterator.hasNext()) {
            String element = listIterator.next();
            System.out.println(element);
        }

        System.out.println("\nBackward iteration:");
        // Backward iteration using ListIterator
        while (listIterator.hasPrevious()) {
            String element = listIterator.previous();
            System.out.println(element);
        }
        
        System.out.println("Forward iteration:");
        // Forward iteration using ListIterator
        while (listIterator.hasNext()) {
            String element = listIterator.next();
            int index = listIterator.previousIndex(); // Get the index of the previous element
            System.out.println("Element: " + element + ", at Index: " + index);
        }

        System.out.println("\nBackward iteration:");
        // Backward iteration using ListIterator
        while (listIterator.hasPrevious()) {
            String element = listIterator.previous();
            int index = listIterator.nextIndex(); // Get the index of the next element
            System.out.println("Element: " + element + ", at Index: " + index);
        }
        

        // Modify elements using ListIterator
        System.out.println("\nModifying elements:");
        listIterator = list.listIterator(); // Reset ListIterator to start

        // Update "Banana" to "Blueberry"
        while (listIterator.hasNext()) {
            String element = listIterator.next();
            if ("Banana".equals(element)) {
                listIterator.set("Blueberry");
            }
        }

        // Print updated ArrayList
        System.out.println("\nUpdated ArrayList:");
        for (String item : list) {
            System.out.println(item);
        }

        // Add an element using ListIterator
        System.out.println("\nAdding an element:");
        listIterator = list.listIterator(); // Reset ListIterator to start
        listIterator.next(); // Move to the first element
        listIterator.add("Fig"); // Add "Fig" before "Banana"

        // Print ArrayList after addition
        System.out.println("\nArrayList after addition:");
        for (String item : list) {
            System.out.println(item);
        }
    }
}
