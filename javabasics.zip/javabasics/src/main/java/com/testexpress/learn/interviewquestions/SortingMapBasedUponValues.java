package com.testexpress.learn.interviewquestions;

import java.util.*;

public class SortingMapBasedUponValues {

	public static void main(String[] args) {
		// Sorting Map based upon the values
		Map<Integer, Integer> map = new HashMap<Integer, Integer>();
		map.put(1, 5);
		map.put(2, 3);
		map.put(7, 6);
		List<Map.Entry<Integer, Integer>> list = new ArrayList<>();
		list.addAll(map.entrySet());
		list.sort(Map.Entry.comparingByValue());
		Map<Integer, Integer> sortedMap = new LinkedHashMap<>();
		for (Map.Entry<Integer, Integer> entry : list) {
			sortedMap.put(entry.getKey(), entry.getValue());
		}
		// Print the sorted map in descending order
		for (Map.Entry<Integer, Integer> entry : sortedMap.entrySet()) {
			System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
		}

	}

}
