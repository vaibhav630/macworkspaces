package com.testexpress.learn.setbasics;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class HashSetPractice {

	public static void main(String[] args) {

        // Create a Set using the default constructor
        Set<String> set = new HashSet<>();

        // Add elements
        set.add("Apple");
        set.add("Banana");
        
        // Add new element (will be added & true is returned)
        System.out.println(set.add("Cherry"));

        // Add duplicate element (will not be added & false returned)
        System.out.println(set.add("Apple"));

        // Query the set: size, has a specific element or not, has any element or not
        System.out.println("Set contains Apple: " + set.contains("Apple"));
        System.out.println("Set size: " + set.size());
        System.out.println("Set is empty: " + set.isEmpty());

        // Remove an element
        set.remove("Banana");
        System.out.println("Set after removing Banana: " + set);

        // Iterate over the set
        System.out.println("Elements in the set:");
        for (String fruit : set) {
            System.out.println(fruit);
        }

        // Convert to array
        String[] array = set.toArray(new String[0]);
        System.out.println("Array elements:");
        for (String fruit : array) {
            System.out.println(fruit);
        }

        // Clear the set
        set.clear();
        System.out.println("Set is empty: " + set.isEmpty());

        // Using the default constructor
        HashSet<String> defaultSet = new HashSet<>();
        defaultSet.add("Apple");
        defaultSet.add("Banana");
        defaultSet.add("Cherry");
        System.out.println("Default HashSet: " + defaultSet);
        
        // Using the constructor with initial capacity
        HashSet<String> initialCapacitySet = new HashSet<>(50);
        initialCapacitySet.add("Apple");
        initialCapacitySet.add("Banana");
        initialCapacitySet.add("Cherry");
        System.out.println("HashSet with initial capacity 50: " + initialCapacitySet);

        // Using the constructor with initial capacity and load factor
        HashSet<String> capacityLoadFactorSet = new HashSet<>(50, 0.5f);
        capacityLoadFactorSet.add("Apple");
        capacityLoadFactorSet.add("Banana");
        capacityLoadFactorSet.add("Cherry");
        System.out.println("HashSet with initial capacity 50 and load factor 0.5: " + capacityLoadFactorSet);

        // Using the constructor with a collection
        HashSet<String> collectionSet = new HashSet<>(defaultSet);
        System.out.println("HashSet created from another collection: " + collectionSet);
        
        // Create and populate a HashSet
        HashSet<String> hashSet = new HashSet<>();
        hashSet.add("Apple");
        hashSet.add("Banana");
        hashSet.add("Cherry");

        // Convert the HashSet to a TreeSet
        TreeSet<String> treeSet = new TreeSet<>(hashSet);

        // Display the TreeSet
        System.out.println("TreeSet from HashSet:");
        for (String element : treeSet) {
            System.out.println(element);
        }
        
        // Convert the TreeSet to a HashSet
        hashSet = new HashSet<>(treeSet);
                
       }

}
