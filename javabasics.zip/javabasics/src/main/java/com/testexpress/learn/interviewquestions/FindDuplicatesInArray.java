package com.testexpress.learn.interviewquestions;

import java.util.HashSet;
import java.util.Set;

public class FindDuplicatesInArray {

	public static void main(String[] args) {
		// Write a Java program to find and print the duplicate elements in an array.

		int[] arr = { 3, 5, 2, 7, 2, 8, 5, 2 };
		findAndPrintDuplicates(arr);
	}

	public static void findAndPrintDuplicates(int[] array) {
		Set<Integer> uniqueElements = new HashSet<>();
		Set<Integer> duplicateElements = new HashSet<>();

		for (int num : array) {
			if (!uniqueElements.add(num)) {
				duplicateElements.add(num);
			}
		}

		System.out.println("Duplicate Elements: " + duplicateElements);
	}

}
