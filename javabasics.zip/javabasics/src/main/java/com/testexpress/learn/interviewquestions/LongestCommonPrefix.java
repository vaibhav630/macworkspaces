package com.testexpress.learn.interviewquestions;

public class LongestCommonPrefix {

	public static void main(String[] args) {
		// Given an array of strings, write a function to find the longest common prefix
		// string amongst them. If there is no common prefix, return an empty string "".
		// Input: ["flower","flow","flight"] Output: "fl"

		String[] strs = { "flower", "flow", "flight" };
		System.out.println(longestCommonPrefix(strs)); // Output: "fl"
	}

	public static String longestCommonPrefix(String[] strs) {
		if (strs == null || strs.length == 0) {
			return "";
		}

		// Take the first string as a reference
		String prefix = strs[0];

		// Compare the prefix with each string in the array
		for (int i = 1; i < strs.length; i++) {
			// Reduce the prefix size until it matches the beginning of the string
			while (strs[i].indexOf(prefix) != 0) {
				prefix = prefix.substring(0, prefix.length() - 1);
				if (prefix.isEmpty()) {
					return "";
				}
			}
		}
		return prefix;
	}

}
