package com.testexpress.learn.interviewquestions;

import java.util.Arrays;


import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class DuplicatesFromArrayOrListUsingStreams {

	public static void main(String[] args) {
		// Finding duplicates from array or list using streams

		List<Integer> numbers = Arrays.asList(1, 2, 2, 3, 3, 3, 4, 5);

		List<Integer> duplicates = numbers.stream().collect(Collectors.groupingBy(n -> n, Collectors.counting()))
				.entrySet().stream().filter(entry -> entry.getValue() > 1).map(Map.Entry::getKey)
				.collect(Collectors.toList());

		System.out.println(duplicates); // Output: [2, 3]
	}

}
