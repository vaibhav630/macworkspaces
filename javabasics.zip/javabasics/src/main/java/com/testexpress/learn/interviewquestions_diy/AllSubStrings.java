package com.testexpress.learn.interviewquestions_diy;

import java.util.ArrayList;

public class AllSubStrings {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "vaibhav";
		allSubstring(str, "v");
	}
		public static void allSubstring(String str, CharSequence vOccurance) {
			
			int countV=0;
			ArrayList<String> list = new ArrayList<>();
			String substring="";
			char eachChar ;
			
			for(int i=0;i<str.length();i++) {
				eachChar = str.charAt(i);
				list.add(String.valueOf(eachChar));
				substring = String.valueOf(eachChar);
				
				for(int j=i+1;j<str.length();j++) {
					substring = substring + str.charAt(j);
					list.add(substring);
				}
				substring = "";
			}
			
			System.out.println(list);
			
			for(String s:list) {
				if(s.contains(vOccurance)) {
				countV++;	
				}
			}
			System.out.println(countV);
	}

}
