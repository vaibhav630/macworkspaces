package com.testexpress.learn.enumbasics;

public class EnumWithSwitch {
	
	enum Status{Running,Failed,Success,Pending,Defaultstate};

	public static void main(String[] args) {
		
		
		Status status = Status.Defaultstate;
		
		
		switch(status)
		{
			case Running: System.out.println("All good");
			break;
			
			case Pending: System.out.println("Please wait");
			break;
			
			case Failed: System.out.println("Try Again");
			break;
			
			case Success: System.out.println("Done");
			break;
			
			default: System.out.println("System in unrecognized state");
			break;
		}
			

	}

}
