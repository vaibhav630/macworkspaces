package com.testexpress.learn.interviewquestions;

public class SecondMaxNumberInArray {

	public static void main(String[] args) {
		// Second max number in array
		int[] numbers = { 10, 5, 8, 15, 7, 20, 18 };

		int firstMax = Integer.MIN_VALUE;
		int secondMax = Integer.MIN_VALUE;

		for (int number : numbers) {
			if (number > firstMax) {
				secondMax = firstMax;
				firstMax = number;
			} else if (number > secondMax && number < firstMax) {
				secondMax = number;
			}
		}

		if (secondMax == Integer.MIN_VALUE) {
			System.out.println("There is no second maximum element.");
		} else {
			System.out.println("The second maximum element is: " + secondMax);
		}
	}

}
