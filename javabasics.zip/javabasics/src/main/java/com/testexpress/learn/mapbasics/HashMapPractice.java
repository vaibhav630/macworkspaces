package com.testexpress.learn.mapbasics;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.ArrayList;
import java.util.Collection;

public class HashMapPractice {

	public static void main(String[] args) {

        // Create a HashMap
        Map<String, Integer> map = new HashMap<>();

        // Add key-value pairs
        map.put("Apple", 1);
        map.put("Banana", 2);
        map.put("Cherry", 3);

        // Display the map
        System.out.println("Map: " + map);

        // Retrieve a value
        System.out.println("Value for 'Banana': " + map.get("Banana"));

        // Remove a key-value pair
        map.remove("Cherry");
        System.out.println("Map after removing 'Cherry': " + map);

        // Check if a key exists
        System.out.println("Map contains 'Apple': " + map.containsKey("Apple"));

        // Check if a value exists
        System.out.println("Map contains value 2: " + map.containsValue(2));

        // Get the size of the map
        System.out.println("Size of the map: " + map.size());

        // Check if the map is empty
        System.out.println("Is map empty: " + map.isEmpty());

        // Clear the map
        map.clear();
        System.out.println("Map after clearing: " + map);

        // Re-add elements
        map.put("Date", 4);
        map.put("Elderberry", 5);

        // Iterate over keys
        System.out.println("Keys in the map:");
        Set<String> keys = map.keySet();
        for (String key : keys) {
            System.out.println(key);
        }

        // Retrieve the key set from the HashMap
        Set<String> keySet = map.keySet();

        // Convert the key set to an array
        String[] keysArray = keySet.toArray(new String[0]);

        // Display the array
        System.out.println("Array of keys:");
        for (String key : keysArray) {
            System.out.println(key);
        }
        
        // Convert the key set to an ArrayList
        ArrayList<String> keysList = new ArrayList<>(keySet);

        // Display the ArrayList
        System.out.println("ArrayList of keys:");
        for (String key : keysList) {
            System.out.println(key);
        }

        // Iterate over values
        System.out.println("Values in the map:");
        Collection<Integer> values = map.values();
        for (Integer value : values) {
            System.out.println(value);
        }
        
        // Retrieve the values from the HashMap
        Collection<Integer> mapvalues = map.values();

        // Convert the values to an array
        Integer[] valuesArray = mapvalues.toArray(new Integer[0]);

        // Display the array
        System.out.println("Array of values:");
        for (Integer value : valuesArray) {
            System.out.println(value);
        }
        
        // Convert the values to an ArrayList
        ArrayList<Integer> valuesList = new ArrayList<>(values);

        // Display the ArrayList
        System.out.println("ArrayList of values:");
        for (Integer value : valuesList) {
            System.out.println(value);
        }
        
        // Convert the values to a Set
        Set<Integer> valuesSet = new HashSet<>(values);

        // Display the Set
        System.out.println("Set of values:");
        for (Integer value : valuesSet) {
            System.out.println(value);
        }

        // Iterate over entries
        System.out.println("Entries in the map:");
        Set<Map.Entry<String, Integer>> entries = map.entrySet();
        for (Map.Entry<String, Integer> entry : entries) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
        
        // Retrieve the entry set from the HashMap
        Set<Map.Entry<String, Integer>> entrySet = map.entrySet();

        // Convert the entry set to an array
        Map.Entry<String, Integer>[] entriesArray = entrySet.toArray(new Map.Entry[0]);

        // Display the array
        System.out.println("Array of map entries:");
        for (Map.Entry<String, Integer> entry : entriesArray) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }
        
        // Convert the entry set to an ArrayList
        ArrayList<Map.Entry<String, Integer>> entriesList = new ArrayList<>(entrySet);

        // Display the ArrayList
        System.out.println("ArrayList of map entries:");
        for (Map.Entry<String, Integer> entry : entriesList) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }
        
//        //Convert the entry set to an treeset
//        TreeSet<Map.Entry<String,Integer>> entriesTreeSet = new TreeSet<>(map.entrySet());

        // Put all elements from another map
        Map<String, Integer> anotherMap = new HashMap<>();
        anotherMap.put("Fig", 6);
        anotherMap.put("Grape", 7);
        map.putAll(anotherMap);
        System.out.println("Map after putAll: " + map);
        
        
    
		
	}

}
