package com.testexpress.learn.interviewquestions;

import java.util.Arrays;

public class CheckAnagrams {

	public static void main(String[] args) {

		// To check if two string are Anagram of each other or not

		System.out.println(checkAnagram("abc", "Bac"));
	}

	public static boolean checkAnagram(String str1, String str2) {
		// Early exit if lengths are different
		if (str1.length() != str2.length()) {
			return false;
		}

		// Convert strings to lower case outside the loop
		str1 = str1.toLowerCase();
		str2 = str2.toLowerCase();

		// Convert strings to character arrays
		char[] charArr1 = str1.toCharArray();
		char[] charArr2 = str2.toCharArray();

		// Sort character arrays
		Arrays.sort(charArr1);
		Arrays.sort(charArr2);

		// Compare sorted arrays directly
		return Arrays.equals(charArr1, charArr2);
	}

}
