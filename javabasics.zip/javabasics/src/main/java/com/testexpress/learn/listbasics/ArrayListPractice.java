package com.testexpress.learn.listbasics;

import java.util.ArrayList;
import java.util.function.Predicate;

public class ArrayListPractice {

	public static void main(String[] args) {
		
        // Create an ArrayList
        ArrayList<String> list = new ArrayList<>();

        // Add elements
        list.add("Apple");
        list.add("Banana");
        list.add("Cherry");
        System.out.println("After add list looks like: " + list);
        list.add(1, "Date");
        System.out.println("After add at index, list looks like: " + list);

        // Access elements
        System.out.println("Element at index 2: " + list.get(2));

        // Update elements
        list.set(2, "Blueberry");
        System.out.println("After update list looks like: " + list);

        // Remove elements
        list.remove(3);
        list.remove("Date");
        System.out.println("After removing elements list looks like: " + list);

        // Query the list: size, has something in it or not?, has a specific element?
        System.out.println("Size of the list: " + list.size());
        System.out.println("Is the list empty? " + list.isEmpty());
        System.out.println("Does the list contain 'Apple'? " + list.contains("Apple"));

        // Iterate over the list
        System.out.println("Elements in the list:");
        for (String fruit : list) {
            System.out.println(fruit);
        }

        // Convert to array
        String[] array = list.toArray(new String[0]);
        System.out.println("Array elements:");
        for (String fruit : array) {
            System.out.println(fruit);
        }

        // Clear the list
        list.clear();
        System.out.println("Size of the list after clearing: " + list.size());
        
        
        // Create an ArrayList
        ArrayList<String> arrlist = new ArrayList<>();

        // Add elements
        arrlist.add("Apple");
        arrlist.add("Banana");
        arrlist.add("Cherry");
        arrlist.add("Date");
        arrlist.add("Elderberry");

        // Clone the ArrayList (ArrayList specific)
        ArrayList<String> clonedarrlist = (ArrayList<String>) arrlist.clone();
        System.out.println("Cloned arrlist: " + clonedarrlist);

        // Ensure capacity (ArrayList specific)
        arrlist.ensureCapacity(20);
        System.out.println("Ensured capacity for 20 elements.");
        
        // Trim to size (ArrayList specific)
        // Trims the capacity of the ArrayList instance to be the list's current size. 
        // An application can use this operation to minimize the storage of an ArrayList instance.
        System.out.println("Size of the list before trimming: " + arrlist.size());
        arrlist.trimToSize();
        System.out.println("Trimmed arrlist size: " + arrlist.size());

        // forEach method (ArrayList specific)
        System.out.println("arrlist elements using forEach:");
        arrlist.forEach(element -> System.out.println(element));

        // removeIf method (ArrayList specific)
        Predicate<String> filter = fruit -> fruit.startsWith("B");
        arrlist.removeIf(filter);
        System.out.println("arrlist after removing elements that start with 'B': " + arrlist);

        // Using spliterator (ArrayList specific)
        System.out.println("Using spliterator:");
        arrlist.spliterator().forEachRemaining(System.out::println);

    }
}
