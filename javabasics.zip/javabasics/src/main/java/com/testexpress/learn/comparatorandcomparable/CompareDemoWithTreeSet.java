package com.testexpress.learn.comparatorandcomparable;

import java.util.Comparator;
import java.util.TreeSet;

public class CompareDemoWithTreeSet {

	public static void main(String[] args) {
		// create a new tree set with MyComparator1
		TreeSet<Integer> treeset = new TreeSet<Integer>(new MyComparator1());

		// add values in tree set
		treeset.add(10);
		treeset.add(0);
		treeset.add(15);
		treeset.add(5);
		treeset.add(20);
		treeset.add(20);

		// display values of tree set
		System.out.println(treeset);

		// create a new tree set with MyComparator2
		TreeSet<Integer> treeset2 = new TreeSet<Integer>(new MyComparator2());

		// add values in tree set
		treeset2.add(10);
		treeset2.add(0);
		treeset2.add(15);
		treeset2.add(5);
		treeset2.add(20);
		treeset2.add(20);

		// display values of tree set
		System.out.println(treeset2);

		// create a new tree set with MyComparator3
		TreeSet<Integer> treeset3 = new TreeSet<Integer>(new MyComparator3());

		// add values in tree set
		treeset3.add(10);
		treeset3.add(0);
		treeset3.add(15);
		treeset3.add(5);
		treeset3.add(20);
		treeset3.add(20);

		// display values of tree set
		System.out.println(treeset3);

	}

}

class MyComparator1 implements Comparator // custom order
{

	@Override
	public int compare(Object o1, Object o2) {
		Integer i1 = (Integer) o1;
		Integer i2 = (Integer) o2;

		if (i1 > i2) {
			return 1;
		} else if (i1 < i2) {
			return -1;
		} else
			return 0;
	}

}

class MyComparator2 implements Comparator // Asc or Desc order using compareTo()
{
	@Override
	public int compare(Object o1, Object o2) {
		Integer i1 = (Integer) o1;
		Integer i2 = (Integer) o2;

		return i1.compareTo(i2); //
		/*
		 * we know above line gives Asc order so, comparision opposite of line70 would
		 * give Desc oder return i2.compareTo(i1); also, -ve of line 70 would give desc
		 * oder return -i1.compareTo(i2); and -ve of line 73 would give Asc order again
		 * return -i2.compareTo(i1);
		 */

		/*
		 * if we always return 1, then insertion order would be preserved if we always
		 * return -1, then elements would be saved in reverse of insertion order if we
		 * always return 0, only 1st element will be inserted and all remaining elements
		 * would not be inserted as they would be considered as duplicate.
		 */
	}

}

class MyComparator3 implements Comparator // Asc or Desc order using compareTo()
{
	@Override
	public int compare(Object o1, Object o2) {
		Integer i1 = (Integer) o1;
		Integer i2 = (Integer) o2;

		 return i1.compareTo(i2); //Asc
		// return i2.compareTo(i1); // Desc
		// return -i1.compareTo(i2); //Desc
		// return -i2.compareTo(i1); //Asc
		// return 1; //then insertion order would be preserved
		// return -1; //then elements would be saved in reverse of insertion order
		// return 0; // only 1st element will be inserted and all remaining elements
		// would not be inserted as they would be considered as duplicate.
	}

}
