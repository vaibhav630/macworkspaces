package com.testexpress.learn.enumbasics;

public class EnumWithMethodsAndConstrutors {
	
	enum Laptops{Macbook(20000), Thinkpad(16000), Latitude(15000), Surface(12000);
	
		private int price;
		
	Laptops(int i) {
		this. price=i;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}}

	public static void main(String[] args) {
		//EnumWithMethodsAndConstrutors
//		Laptops lap = Laptops.Macbook;
//		System.out.println();
		
		for(Laptops lap:Laptops.values()){
		System.out.println(lap + " comes in price: "+ lap.getPrice());	
		}
		
	}

}
