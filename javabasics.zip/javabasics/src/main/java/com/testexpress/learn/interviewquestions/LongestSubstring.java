package com.testexpress.learn.interviewquestions;

import java.util.HashSet;
import java.util.Set;

public class LongestSubstring {

	public static void main(String[] args) {
		// Write a Java program to find the length of the longest substring without repeating characters.
		maxLength("abca");
		
	}

	public static void maxLength(String strs) {
		int maxLength=0, len = 0;
		int r = 0;
		Set<Character> set = new HashSet<>();
		for (r = 0; r < strs.length(); r++) {
			char c = strs.charAt(r);
			if (set.contains(c)) {
				set.remove(c);
			}
			set.add(c);
			maxLength = Math.max(maxLength, set.size()); //set.size would be enough
			len = set.size();	
		}
		System.out.println(maxLength);
		System.out.println(len);
	}

}
