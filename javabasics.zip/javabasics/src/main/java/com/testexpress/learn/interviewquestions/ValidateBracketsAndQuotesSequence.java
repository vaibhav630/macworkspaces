package com.testexpress.learn.interviewquestions;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Stack;

public class ValidateBracketsAndQuotesSequence {

	public static void main(String[] args) {
//		Problem: 
//			Given a string containing just the characters '(', ')', '{', '}', '[' and ']', 
//			determine if the input string is valid. An input string is valid if:
//			Open brackets must be closed by the same type of brackets.
//			Open brackets must be closed in the correct order.
//			Input: "()[]{}" Output: true
//			Input: “(){[]}" Output =true
//			Input: “(){[}}" Output=true
		System.out.println(ValidateBracketsAndQuotesSeqInString("()[]{}"));
	}

	public static Boolean ValidateBracketsAndQuotesSeqInString(String str) {
		// Remove non-bracket characters
		String s = str.replaceAll("[^\\(\\)\\{\\}\\[\\]]", "");

		// Map to define matching pairs
		Map<Character, Character> charMap = new LinkedHashMap<>();
		charMap.put('(', ')');
		charMap.put('[', ']');
		charMap.put('{', '}');

		// Stack to keep track of opening brackets
		Stack<Character> stack = new Stack<>();

		// Traverse the string character by character
		for (char c : s.toCharArray()) {
			// If the character is an opening bracket, push it onto the stack
			if (charMap.containsKey(c)) {
				stack.push(c);
			}
			// If the character is a closing bracket
			else if (charMap.containsValue(c)) {
				// If the stack is empty or the top of the stack does not match the closing
				// bracket, return false
				if (stack.isEmpty() || charMap.get(stack.pop()) != c) {
					return false;
				}
			}
		}
		// If the stack is empty, all opening brackets have been matched
		return stack.isEmpty();

	}

}
