package com.testexpress.learn.Iteratorsbasics;

import java.util.ArrayList;
import java.util.Iterator;

public class InteratorPractice {

	public static void main(String[] args) {
		// create a new Array List
		ArrayList<Integer> arrlist = new ArrayList<>();
		
		//assign values to array list
		for(int i=0;i<10;i++) {
			arrlist.add(i);
		}
		System.out.println(arrlist);
		
		//create iterator
		Iterator itr = arrlist.iterator();
		
		while(itr.hasNext()) {                 // check if array list has more elements
			Integer i = (Integer) itr.next();  //next method of iterator
			
		if(i%2==0)
			System.out.println(i);
		else
			itr.remove();  //remove using iterator
		}
		
		System.out.println("arlist size after itr.remove: "+arrlist.size());

	}

}
