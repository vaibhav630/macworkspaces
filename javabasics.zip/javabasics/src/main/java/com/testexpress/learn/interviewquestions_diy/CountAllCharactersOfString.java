package com.testexpress.learn.interviewquestions_diy;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.stream.Collectors;

public class CountAllCharactersOfString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		countAllCharInString("Vaibhav");

	}

	private static void countAllCharInString(String str) {
		LinkedHashMap<Character,Integer> map = new LinkedHashMap<>();
		
		for(char ch: str.toCharArray()) {
			map.put(ch, map.getOrDefault(ch, 0)+1);
			
		}
		
		List<Character> list = map.entrySet().stream().filter(entry -> entry.getValue()==1)
				.map(entry->entry.getKey()).collect(Collectors.toList());
		
		
	}

}
