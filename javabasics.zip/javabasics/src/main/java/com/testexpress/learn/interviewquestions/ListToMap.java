package com.testexpress.learn.interviewquestions;

import java.util.ArrayList;
import java.util.stream.Collectors;
import java.util.List;
import java.util.Map;

public class ListToMap {

	public static void main(String[] args) {
		//Convert List<String> to Map<String , Integer> where key is list element itself 
		//and value is its length.

		List<String> list = new ArrayList<String>();
		list.add("apple");
		list.add("banana");
		list.add("mango");
		
		Map<String,Integer> map = list.stream().
				collect(Collectors.toMap(n -> n, n -> n.length()));
		
		map.entrySet().stream().
		forEach(entry -> System.out.println(entry.getKey() + ":" + entry.getValue()));

	}

}
