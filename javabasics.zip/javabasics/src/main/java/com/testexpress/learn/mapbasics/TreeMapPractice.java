package com.testexpress.learn.mapbasics;

import java.util.TreeMap;
import java.util.Map;

public class TreeMapPractice {

	public static void main(String[] args) {
        // Create and populate a TreeMap
        TreeMap<String, Integer> treeMap = new TreeMap<>();
        treeMap.put("Apple", 1);
        treeMap.put("Banana", 2);
        treeMap.put("Cherry", 3);
        treeMap.put("Date", 4);

        // firstEntry()
        Map.Entry<String, Integer> firstEntry = treeMap.firstEntry();
        System.out.println("First Entry: " + firstEntry);

        // lastEntry()
        Map.Entry<String, Integer> lastEntry = treeMap.lastEntry();
        System.out.println("Last Entry: " + lastEntry);

        // lowerEntry()
        Map.Entry<String, Integer> lowerEntry = treeMap.lowerEntry("Cherry");
        System.out.println("Entry lower than 'Cherry': " + lowerEntry);

        // higherEntry()
        Map.Entry<String, Integer> higherEntry = treeMap.higherEntry("Cherry");
        System.out.println("Entry higher than 'Cherry': " + higherEntry);

        // floorEntry()
        Map.Entry<String, Integer> floorEntry = treeMap.floorEntry("Cherry");
        System.out.println("Floor entry for 'Cherry': " + floorEntry);

        // ceilingEntry()
        Map.Entry<String, Integer> ceilingEntry = treeMap.ceilingEntry("Cherry");
        System.out.println("Ceiling entry for 'Cherry': " + ceilingEntry);

        // pollFirstEntry()
        Map.Entry<String, Integer> polledFirstEntry = treeMap.pollFirstEntry();
        System.out.println("Polled First Entry: " + polledFirstEntry);
        System.out.println("TreeMap after polling first entry: " + treeMap);

        // pollLastEntry()
        Map.Entry<String, Integer> polledLastEntry = treeMap.pollLastEntry();
        System.out.println("Polled Last Entry: " + polledLastEntry);
        System.out.println("TreeMap after polling last entry: " + treeMap);

        // descendingMap()
        TreeMap<String, Integer> descendingMap = new TreeMap<>(treeMap.descendingMap());
        System.out.println("Descending TreeMap: " + descendingMap);
    }
}


class TreeMapExample {
    public static void main(String[] args) {
        // Create and populate a TreeMap with student names and scores
        TreeMap<String, Integer> studentScores = new TreeMap<>();
        studentScores.put("Alice", 85);
        studentScores.put("Bob", 92);
        studentScores.put("Charlie", 78);
        studentScores.put("Diana", 88);
        studentScores.put("Eve", 91);

        // Example usage of floorEntry()
        Map.Entry<String, Integer> floorEntry = studentScores.floorEntry("Dan");
        if (floorEntry != null) {
            System.out.println("Floor entry for 'Dan': " + floorEntry.getKey() + " = " + floorEntry.getValue());
        } else {
            System.out.println("No floor entry found for 'Dan'");
        }

        // Example usage of ceilingEntry()
        Map.Entry<String, Integer> ceilingEntry = studentScores.ceilingEntry("Dan");
        if (ceilingEntry != null) {
            System.out.println("Ceiling entry for 'Dan': " + ceilingEntry.getKey() + " = " + ceilingEntry.getValue());
        } else {
            System.out.println("No ceiling entry found for 'Dan'");
        }

        // Example usage of floorEntry() for a key that exists
        floorEntry = studentScores.floorEntry("Diana");
        if (floorEntry != null) {
            System.out.println("Floor entry for 'Diana': " + floorEntry.getKey() + " = " + floorEntry.getValue());
        } else {
            System.out.println("No floor entry found for 'Diana'");
        }

        // Example usage of ceilingEntry() for a key that exists
        ceilingEntry = studentScores.ceilingEntry("Diana");
        if (ceilingEntry != null) {
            System.out.println("Ceiling entry for 'Diana': " + ceilingEntry.getKey() + " = " + ceilingEntry.getValue());
        } else {
            System.out.println("No ceiling entry found for 'Diana'");
        }
    }
}

