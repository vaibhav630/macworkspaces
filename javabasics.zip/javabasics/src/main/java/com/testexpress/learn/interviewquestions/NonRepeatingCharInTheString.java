package com.testexpress.learn.interviewquestions;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import java.util.stream.Collectors;

public class NonRepeatingCharInTheString {
	
	// Find the first non repeating char in the String
	public static void main(String[] args) {
		
		String input = "aabccbd";
		Map<Character, Integer> map = new LinkedHashMap<>();
		for (char c : input.toCharArray()) {
			map.put(c, map.getOrDefault(c, 0) + 1);
		}
		List<Character> list = map.entrySet().stream().filter(entry -> entry.getValue() == 1)
				.map(entry -> entry.getKey()).collect(Collectors.toList());
		System.out.println(list.get(0));// output should be d as all other are repeating

	}

}
