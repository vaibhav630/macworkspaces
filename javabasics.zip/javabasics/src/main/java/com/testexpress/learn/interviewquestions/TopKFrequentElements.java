package com.testexpress.learn.interviewquestions;

import java.util.*;

public class TopKFrequentElements {

	public static void main(String[] args) {
		// Write a program that finds the k most frequent elements in a given array of
		// integers.
		TopKFrequentElements solution = new TopKFrequentElements();
		int[] arrint = { 1, 1, 2, 2, 2, 3, 3, 3, 4, 4 };
		int k = 2;
		List<Integer> result = solution.topKFrequent(arrint, k);
		System.out.println("Top " + k + " frequent elements: " + result);
	}

	public List<Integer> topKFrequent(int[] nums, int k) {
		// Step 1: Create the frequency map
		Map<Integer, Integer> frequencyMap = new HashMap<>();
		for (int num : nums) {
			frequencyMap.put(num, frequencyMap.getOrDefault(num, 0) + 1);
		}

		// Step 2: Create a min-heap (priority queue) to keep the top k frequent
		// elements
		PriorityQueue<Map.Entry<Integer, Integer>> minHeap = new PriorityQueue<>(
				Comparator.comparingInt(Map.Entry::getValue));

		// Step 3: Iterate through the frequency map
		for (Map.Entry<Integer, Integer> entry : frequencyMap.entrySet()) {
			minHeap.add(entry);
			if (minHeap.size() > k) {
				minHeap.poll(); // Remove the element with the smallest frequency
			}
		}

		// Step 4: Extract the elements from the min-heap
		List<Integer> topKFrequentElements = new ArrayList<>();
		while (!minHeap.isEmpty()) {
			topKFrequentElements.add(minHeap.poll().getKey());
		}

		// Optional: Reverse the list if you want to maintain the order of most frequent
		// elements first
		Collections.reverse(topKFrequentElements);

		return topKFrequentElements;
	}

}
